// Get the form element
const form = document.querySelector('form');

// Add a submit event listener to the form
form.addEventListener('submit', function(event) {
  // Get the input values
  const present_price = parseFloat(form.elements.present_price.value);
  const kms_driven = parseInt(form.elements.kms_driven.value);
  const past_owners = parseInt(form.elements.past_owners.value);
  const age = parseInt(form.elements.age.value);

  // Get the select options
  const seller_type = form.elements.seller_type.value;
  const fuel_type = form.elements.fuel_type.value;
  const transmission = form.elements.transmission.value;

  // Check if the present price is a number
  if (isNaN(present_price)) {
    alert('Please enter a valid present price.');
    event.preventDefault();
    return false;
  }

  // Check if the kilometers driven is a number
  if (isNaN(kms_driven)) {
    alert('Please enter a valid kilometers driven.');
    event.preventDefault();
    return false;
  }

  // Check if the past owners is a number
  if (isNaN(past_owners)) {
    alert('Please enter a valid number of past owners.');
    event.preventDefault();
    return false;
  }

  // Check if the age is a number
  if (isNaN(age)) {
    alert('Please enter a valid age.');
    event.preventDefault();
    return false;
  }

  // Check if a seller type is selected
  if (seller_type === '') {
    alert('Please select a seller type.');
    event.preventDefault();
    return false;
  }

  // Check if a fuel type is selected
  if (fuel_type === '') {
    alert('Please select a fuel type.');
    event.preventDefault();
    return false;
  }

  // Check if a transmission is selected
  if (transmission === '') {
    alert('Please select a transmission.');
    event.preventDefault();
    return false;
  }
});
